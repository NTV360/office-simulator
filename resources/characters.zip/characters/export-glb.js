// Exports every preset to glb/<style>/<key>.glb with all animation clips.
// Run: npm i && node export-glb.js
import * as THREE from 'three';
import { GLTFExporter } from 'three/examples/jsm/exporters/GLTFExporter.js';
import { mkdirSync, writeFileSync } from 'node:fs';
import { Character, PRESETS } from './characters.js';

globalThis.FileReader ??= class {
  readAsArrayBuffer(b) { b.arrayBuffer().then((r) => { this.result = r; this.onloadend?.(); }); }
  readAsDataURL(b) { b.arrayBuffer().then((r) => { this.result = `data:${b.type || 'application/octet-stream'};base64,${Buffer.from(r).toString('base64')}`; this.onloadend?.(); }); }
};
const warn = console.warn; console.warn = (m, ...r) => (String(m).includes('normalized normal') ? 0 : warn(m, ...r));

const jobs = [
  ['blocky', PRESETS.blocky, {}],
  ['chibi', PRESETS.chibi, {}],
];
for (const [dir, set, extra] of jobs) {
  mkdirSync(`glb/${dir}`, { recursive: true });
  for (const [key, preset] of Object.entries(set)) {
    const c = new Character(THREE, { ...preset, ...extra });
    c.mixer.stopAllAction();
    c.root.name = preset.name;
    const scene = new THREE.Scene();
    scene.add(c.root);
    const glb = await new GLTFExporter().parseAsync(scene, { binary: true, animations: c.clips });
    writeFileSync(`glb/${dir}/${key}.glb`, Buffer.from(glb));
  }
  console.log(`glb/${dir}: ${Object.keys(set).length} files`);
}
